<?php
include 'db_connection.php';

// Verificar que el usuario tenga el rol de artesano
session_start();
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'artesano') {
    echo "<script>
              alert('No tienes el rol de Artesano');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

// Obtener el nombre del producto a eliminar
$nombre_producto = $_POST['nombre_producto'];

// Primero, obtenemos el CodProducto del producto que queremos eliminar
$sql_select = "SELECT CodProducto FROM Producto WHERE Nombre = ?";
$stmt_select = $conn->prepare($sql_select);
$stmt_select->bind_param("s", $nombre_producto);
$stmt_select->execute();
$result_select = $stmt_select->get_result();

if ($result_select->num_rows > 0) {
    $row = $result_select->fetch_assoc();
    $codProducto = $row['CodProducto'];

    // Eliminar los registros del inventario relacionados con el producto
    $sql_delete_inventario = "DELETE FROM Inventario WHERE CodProducto = ?";
    $stmt_delete_inventario = $conn->prepare($sql_delete_inventario);
    $stmt_delete_inventario->bind_param("i", $codProducto);
    $stmt_delete_inventario->execute();

    // Luego, eliminamos el producto de la tabla Producto
    $sql_delete_producto = "DELETE FROM Producto WHERE CodProducto = ?";
    $stmt_delete_producto = $conn->prepare($sql_delete_producto);
    $stmt_delete_producto->bind_param("i", $codProducto);

    if ($stmt_delete_producto->execute()) {
        echo "<script>alert('Producto y su inventario eliminados correctamente'); window.location.href = '../views/productos/index.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar el producto'); window.location.href = '../views/subir_producto.php';</script>";
    }

    $stmt_delete_inventario->close();
    $stmt_delete_producto->close();
} else {
    echo "<script>alert('Producto no encontrado'); window.location.href = '../views/subir_producto.php';</script>";
}

$stmt_select->close();
$conn->close();
?>
