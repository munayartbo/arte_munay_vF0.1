<?php
include 'db_connection.php';

if (isset($_POST['cod_pedido']) && isset($_POST['cod_delivery'])) {
    $cod_pedido = $_POST['cod_pedido'];
    $cod_delivery = $_POST['cod_delivery'];

    // Iniciar transacción
    $conn->begin_transaction();

    try {
        // Actualizar el pedido con el delivery asignado y cambiar el estado a 'asignado'
        $sql_update_pedido = "UPDATE pedido SET Estado = 'Asignado' WHERE CodPedido = '$cod_pedido'";
        
        if ($conn->query($sql_update_pedido) === TRUE) {
            // Insertar en la tabla de entrega
            $sql_insert_entrega = "INSERT INTO entrega (CodDelivery, CodPedido, Hora) VALUES ('$cod_delivery', '$cod_pedido', NOW())";
            if ($conn->query($sql_insert_entrega) === TRUE) {
                // Confirmar la transacción
                $conn->commit();
                echo "<script>alert('Delivery asignado correctamente'); window.location.href = '../views/dashbord_MunayArt';</script>";
            } else {
                throw new Exception("Error al insertar en la tabla de entrega");
            }
        } else {
            throw new Exception("Error al asignar el delivery");
        }
    } catch (Exception $e) {
        // Deshacer la transacción en caso de error
        $conn->rollback();
        echo "<script>alert('".$e->getMessage()."'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Datos incompletos'); window.history.back();</script>";
}

$conn->close();
?>
