<?php
// Habilitar la visualización de errores para depuración
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Definir las respuestas del chatbot por rol
// Respuestas del chatbot por rol
$respuestas = [
    'cliente' => [
        'productos' => 'En nuestra tienda tenemos una gran variedad de productos artesanales, desde cerámica hasta textiles. ¿Te gustaría ver algunos de ellos o necesitas algo en particular?',
        'precios' => 'Los precios de nuestros productos varían dependiendo de los materiales y la complejidad del diseño. Si quieres, puedo mostrarte algunos productos con sus precios. ¿Te interesa?',
        'descuentos' => '¡Sí! Actualmente tenemos algunas ofertas especiales en productos seleccionados. Te invito a que revises nuestra sección de promociones, ¡quizá encuentres algo que te guste!',
        'envío' => 'Ofrecemos varias opciones de envío según tu ubicación. Si quieres, puedo informarte sobre el tiempo de entrega estimado. ¿Te gustaría saber más?',
        'pago' => 'Aceptamos varios métodos de pago como tarjeta de crédito, débito, y transferencias. Si necesitas ayuda con el proceso de pago, no dudes en pedírmelo.',
        'tiempo de entrega' => 'El tiempo de entrega depende de la zona a la que se envíen los productos y del tipo de artículo. ¿Te gustaría saber cuánto tiempo tardaría en llegar tu pedido?',
        'contacto' => 'Puedes contactarnos por correo electrónico o a través de nuestras redes sociales. Estamos disponibles para ayudarte en cualquier momento. ¿Necesitas el contacto?',
        'horarios' => 'Nuestro horario de atención es de lunes a viernes, de 9:00 AM a 6:00 PM. Si necesitas algo fuera de este horario, también puedes escribirnos y te responderemos lo más pronto posible.',
        'hola' => 'Hola encantado soy Munay, en que puedo ayudarte el día de hoy?'
    ],
    'artesano' => [
        'subir productos' => '¡Hola, artesano! Para subir tus productos, solo tienes que acceder a tu panel de control de artesano. Allí podrás cargar fotos, descripciones y precios. Si tienes alguna pregunta sobre cómo hacerlo, ¡te puedo guiar!',
        'gestionar ventas' => 'Desde tu perfil de artesano puedes ver tus ventas, gestionar tus productos y comprobar los pedidos que has recibido. Si necesitas saber cómo hacer algo en el panel, puedo ayudarte a encontrarlo.',
        'beneficios' => 'Como artesano en nuestra plataforma, tienes la oportunidad de llegar a miles de personas. Puedes vender tus productos, establecer tus precios y disfrutar de un mercado global. ¿Te gustaría saber más sobre los beneficios de vender aquí?',
        'soporte' => 'Si tienes dudas o problemas, nuestro equipo de soporte está listo para ayudarte. Puedes contactarnos en cualquier momento, y resolveremos tu inquietud lo más rápido posible. ¿Necesitas asistencia con algo específico?',
        'hola' => 'Hola encantado soy Munay, en que puedo ayudarte el día de hoy?'
    ],
    'delivery' => [
        'entregar productos' => '¡Hola, repartidor! Los productos deben ser entregados según las zonas de cobertura que has seleccionado. Si no estás seguro de las zonas asignadas, puedo ayudarte a revisarlas.',
        'actualizar estado' => 'Puedes actualizar el estado de las entregas desde tu panel de control. Asegúrate de hacerlo después de cada entrega para mantener todo actualizado. ¿Quieres saber cómo actualizar el estado de un pedido?',
        'más pedidos' => 'Recuerda que tienes la opción de ver más pedidos disponibles a través del panel. Asegúrate de estar disponible en las zonas que te han asignado. ¿Te gustaría ver más detalles de los pedidos en tu zona?',
        'problemas con la entrega' => 'Si tienes algún problema con la entrega, por ejemplo, si no encuentras la dirección o hay un inconveniente, por favor infórmanos y te ayudaremos. ¿Te gustaría saber cómo reportar un problema?',
        'cambiar zona de entrega' => 'Si necesitas cambiar tu zona de cobertura, puedes hablar con el administrador. Ellos podrán ayudarte a modificar tu zona. ¿Te gustaría saber cómo contactarlo?',
        'hola' => 'Hola encantado soy Munay, en que puedo ayudarte el día de hoy?'
    ]
];

// Función para obtener la respuesta basada en el mensaje y el rol
function obtenerRespuesta($message, $rol) {
    global $respuestas;

    // Comprobamos si el rol existe y si tiene respuestas definidas
    if (isset($respuestas[$rol])) {
        // Buscamos una respuesta para el mensaje
        foreach ($respuestas[$rol] as $clave => $respuesta) {
            if (strpos(strtolower($message), strtolower($clave)) !== false) {
                return $respuesta;  // Devolvemos la respuesta si la encontramos
            }
        }
    }

    // Si no se encuentra una respuesta, devolvemos un mensaje por defecto
    return "Lo siento, no entiendo esa pregunta. ¿Podrías reformularla?";
}

// Verificar que los parámetros 'message' y 'rol' están presentes en la solicitud
if (isset($_POST['message']) && isset($_POST['rol'])) {
    $message = $_POST['message'];
    $rol = $_POST['rol'];

    // Obtener la respuesta adecuada según el mensaje y el rol
    $respuesta = obtenerRespuesta($message, $rol);

    // Devolver la respuesta en formato JSON
    echo json_encode(['response' => $respuesta]);
} else {
    // Si los parámetros no están presentes, devolver un error
    echo json_encode(['response' => 'Error: Datos incompletos.']);
}
?>