<?php
session_start();
include 'db_connection.php';

// Verificar si el cliente ha iniciado sesión
if (isset($_SESSION['user_id'])) {
    $codCliente = $_SESSION['user_id'];

    // Obtener el email del cliente desde la tabla Usuario
    $query = "SELECT u.Email, u.Nombre, u.Apellido FROM Usuario u
              JOIN Cliente c ON u.CodUsuario = c.CodCliente
              WHERE c.CodCliente = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $codCliente);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $email = $row['Email'];
        $nombre = $row['Nombre'];
        $apellido = $row['Apellido'];

        // Configura los detalles del correo
        $asunto = "Confirmación de compra - MunayArt";
        $mensaje = "Estimado/a $nombre $apellido,\n\nGracias por tu compra. Tu pedido ha sido confirmado y está siendo procesado. Te avisaremos cuando esté en camino.\n\nAtentamente,\nEquipo MunayArt";
        $cabeceras = "From: munayart.bo@gmail.com\r\n";
        $cabeceras .= "Content-Type: text/plain; charset=UTF-8\r\n";

        // Envía el correo
        if (mail($email, $asunto, $mensaje, $cabeceras)) {
            header("Location: ../views/productos/vista_pedido_clientes.php");
            exit();
        } else {
            header("Location: ../views/productos/vista_pedido_clientes.php");
            exit();
        }
    } else {
        header("Location: ../views/productos/vista_pedido_clientes.php");
        exit();
    }

    // Cerrar la conexión y la consulta
    $stmt->close();
    $conn->close();
} else {
    echo "";
    echo "<script>
              alert('Usuario no autenticado.');
              window.location.href = '../views/loginIniReg.php';
          </script>";
}
?>
