<?php
session_start();
include 'db_connection.php';

// Verificar que el usuario tenga el rol de administrador

if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'administrador') {
    echo "<script>
              alert('No tienes el rol de Administrador');
              window.location.href = '../views/loginIniReg.php';
          </script>";
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $habitantes = $_POST['habitantes'];
    $admin = $_POST['admin'];

    // Verificar si los datos no están vacíos
    if (!empty($nombre) && !empty($habitantes) && !empty($admin)) {
        $sql = "INSERT INTO comunidad (Nombre, NroHabitantes, CodAdmi) VALUES ('$nombre', '$habitantes', '$admin')";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Comunidad agregada exitosamente'); window.location.href = '../views/dashbord_MunayArt/';</script>";
        } else {
            echo "Error al agregar la comunidad: " . $conn->error;
        }
    } else {
        echo "Todos los campos son obligatorios.";
    }
}
$conn->close();
?>
