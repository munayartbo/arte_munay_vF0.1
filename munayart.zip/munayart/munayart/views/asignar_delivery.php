<?php
session_start();
include '../controllers/db_connection.php';

if (!isset($_GET['cod_pedido'])) {
    echo "<p>Error: Pedido no especificado.</p>";
    exit();
}

$cod_pedido = $_GET['cod_pedido'];

// Obtener el departamento del pedido específico
$sql_departamento = "
    SELECT u.Departamento
    FROM Pedido p
    JOIN Ubicacion u ON p.CodUbicacion = u.CodUbicacion
    WHERE p.CodPedido = ?
";

// Preparar la consulta para obtener el departamento
$stmt = $conn->prepare($sql_departamento);
$stmt->bind_param("i", $cod_pedido);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<p>Error: Pedido no encontrado.</p>";
    exit();
}

$row = $result->fetch_assoc();
$departamento_pedido = $row['Departamento'];

// Obtener los deliverys disponibles para el departamento del pedido
$sql_deliverys = "
    SELECT DISTINCT d.CodDelivery, u.Nombre, u.Apellido, d.TipoVehiculo, d.ZonaCobertura, d.HoraIngreso, d.HoraSalida
    FROM Pedido p
    JOIN Ubicacion ub ON p.CodUbicacion = ub.CodUbicacion
    JOIN Delivery d ON ub.Departamento = d.ZonaCobertura
    JOIN Usuario u ON d.CodDelivery = u.CodUsuario
    WHERE 
    (
        (d.HoraIngreso <= NOW() AND d.HoraSalida >= NOW())  -- Turnos normales
        OR 
        (d.HoraIngreso > d.HoraSalida AND (d.HoraIngreso <= NOW() OR d.HoraSalida >= NOW()))  -- Turnos que cruzan la medianoche
    )
    AND d.ZonaCobertura = ?  -- Filtrar por el departamento del pedido
";

$stmt = $conn->prepare($sql_deliverys);
$stmt->bind_param("s", $departamento_pedido);
$stmt->execute();
$result_deliverys = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Delivery</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
            color: #333;
        }

        h1,
        h2 {
            text-align: center;
            color: #D64045;
        }

        h1 {
            padding: 20px;
            background-color: #D64045;
            color: white;
        }

        form {
            background-color: white;
            margin: 20px auto;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        input[type="text"],
        input[type="number"],
        input[type="date"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button,
        input[type="submit"] {
            background-color: #D64045;
            color: white;
            border: none;
            padding: 10px 20px;
            text-align: center;
            font-size: 16px;
            cursor: pointer;
            border-radius: 4px;
            width: 100%;
        }

        button:hover,
        input[type="submit"]:hover {
            background-color: #45a049;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #D64045;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            padding: 10px;
            background-color: white;
            margin: 10px auto;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 90%;
        }

        li a {
            color: #D64045;
            text-decoration: none;
            font-weight: bold;
        }

        li a:hover {
            text-decoration: underline;
        }

        /* Estilos para el logo */
        .logo {
            position: absolute;
            top: 20px;
            left: 20px;
            width: 220px;
        }
    </style>
</head>
<body>

<?php
if ($result_deliverys->num_rows > 0) {
    echo "<h2>Asignar Delivery al Pedido $cod_pedido</h2>";
    echo "<form action='../controllers/procesar_asignacion.php' method='post'>
            <input type='hidden' name='cod_pedido' value='$cod_pedido'>
            <label for='delivery'>Seleccionar Delivery:</label>
            <select name='cod_delivery' required>";
    
    while ($row = $result_deliverys->fetch_assoc()) {
        echo "<option value='{$row['CodDelivery']}'>{$row['Nombre']} {$row['Apellido']} - {$row['TipoVehiculo']}</option>";
    }

    echo "</select><br>
          <button type='submit'>Asignar Delivery</button>
          </form>";
} else {
    echo "<p>No hay deliverys disponibles para asignar en este momento.</p>";
}
?>

</body>
</html>

<?php
$conn->close();
?>