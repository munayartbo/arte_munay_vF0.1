<?php
session_start();
include '../../models/db_connection.php'; // Incluye la conexión a la base de datos

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Usuario no autenticado"]);
    exit();
}

// Obtener los datos del formulario
$comentario = $_POST['comentario'] ?? '';
$calificacion = $_POST['calificacion'] ?? '';
$codCliente = $_SESSION['user_id']; // Obtener el ID del usuario de la sesión
$codProducto = $_POST['codProducto'] ?? ''; // Asegúrate de enviar este valor desde el formulario

if (!empty($comentario) && !empty($calificacion) && !empty($codProducto)) {
    // Preparar la consulta para insertar la reseña
    $query = "INSERT INTO Resenia (Comentario, Calificacion, CodCliente, CodProducto) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("siii", $comentario, $calificacion, $codCliente, $codProducto);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Reseña guardada exitosamente"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Error al guardar la reseña"]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => "error", "message" => "Todos los campos son requeridos"]);
}

// Cerrar la conexión
$conn->close();
?>
