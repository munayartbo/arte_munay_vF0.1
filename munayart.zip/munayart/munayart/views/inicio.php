<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MunayArt_INICIO</title>

    <!-- =================================
           PRINCIPAL
        ================================== -->

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- ICONS: Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

    <!-- ICONS: Line Awesome -->
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Animaciones AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">


    <!-- Mis Estilos -->
    <link rel="stylesheet" href="css/styles.css">


    <!-- =================================    
        ================================== -->





</head>

<body>
    <div class="hm-header" style="display: none;"></div>

    <div class="hm-wrapper">
        <!-- =================================
           BANNER
        ================================== -->
        <div class="hm-banner">
            <div class="img-banner">
                <img src="imagenes/img-banner.jpg" alt="">
            </div>
            <a href=""></a>
        </div>

        <!-- =================================
           PROMOCIONES
        ================================== -->
        <div class="hm-page-block bg-fondo"></div>

        <div class="container">

            <div class="header-title" data-aos="fade-up">
                <h1>Promociones</h1>
            </div>

            <iframe src="promociones.php" style="width: 100%; height: 400px; border: none; " scrolling="no"></iframe>



        </div>

        <!-- =================================
           HOME CATEGROIAS
        ================================== -->
        <div class="hm-page-block">
            <div class="container">
                <div class="header-title">
                    <h1 data-aos="fade-up" data-aos-duration="3000">Categorías</h1>
                </div>

                <div class="hm-grid-category">



                    <div class="grid-item" data-aos="fade-up" data-aos-duration="1000">
                        <a href="productos/index.php?categoria=Aretes" target="_top">
                            <img src="productos/img/aretes/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;" id="Aretes">Aretes</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="1500">
                        <a href="productos/index.php?categoria=Cerámica" target="_top">
                            <img src="productos/img/ceramicas/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;" id="Cerámica">Cerámica</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="2000">
                        <a href="productos/index.php?categoria=Chompa" target="_top">
                            <img src="productos/img/chompas/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;" id="Chompa">Chompa</h3>
                            </div>
                        </a>
                    </div>

                    <div class="grid-item" data-aos="fade-up" data-aos-duration="2000">
                        <a href="productos/index.php?categoria=Collar" target="_top">
                            <img src="productos/img/collares/01.webp" alt="">
                            <div class="c-info">
                                <h3 style="color: #fff;" id="Collar">Collar</h3>
                            </div>
                        </a>
                    </div>

                </div>

            </div>
        </div>


        <!-- =================================
           HOME PRODUCTOS DESTACADOS
        ================================== -->
        <?php
        include('../models/db_connection.php');

        // Obtener los tipos de productos (categorías) dinámicamente
        $sqlTipos = "SELECT DISTINCT Tipo FROM Producto";
        $resultTipos = $conn->query($sqlTipos);

        $productosPorTipo = [];

        if ($resultTipos->num_rows > 0) {
            // Recorrer cada tipo de producto
            while ($rowTipo = $resultTipos->fetch_assoc()) {
                $tipo = $rowTipo['Tipo'];

                // Obtener hasta 4 productos por cada tipo
                $sqlProductos = "SELECT Nombre, Precio, Imagen FROM Producto WHERE Tipo = '$tipo' LIMIT 4";
                $resultProductos = $conn->query($sqlProductos);

                if ($resultProductos->num_rows > 0) {
                    $productosPorTipo[$tipo] = $resultProductos->fetch_all(MYSQLI_ASSOC);
                }
            }
        }
        ?>

        <!-- =================================
           HOME PRODUCTOS DESTACADOS
        ================================== -->
        <div class="hm-page-block bg-fondo">
            <div class="container">

                <div class="header-title" data-aos="fade-up">
                    <h1>Productos populares</h1>
                </div>

                <!-- TABS -->
                <ul class="hm-tabs" data-aos="fade-up">
                    <?php foreach ($productosPorTipo as $tipo => $productos): ?>
                        <li class="hm-tab-link"><?php echo htmlspecialchars($tipo); ?></li>
                    <?php endforeach; ?>
                </ul>

                <!-- CONTENIDO DE LOS TABS -->
                <?php foreach ($productosPorTipo as $tipo => $productos): ?>
                    <div class="tabs-content" data-aos="fade-up">
                        <div class="grid-product">
                            <?php foreach ($productos as $producto): ?>
                                <div class="product-item">
                                    <div class="p-portada">
                                        <a href="">
                                            <img src="productos/<?php echo htmlspecialchars($producto['Imagen']); ?>"
                                                alt="<?php echo htmlspecialchars($producto['Nombre']); ?>">
                                        </a>
                                    </div>
                                    <div class="p-info">
                                        <a href="">
                                            <h3><?php echo htmlspecialchars($producto['Nombre']); ?></h3>
                                        </a>
                                        <div class="precio">
                                            <span>Bs./ <?php echo htmlspecialchars($producto['Precio']); ?></span>
                                        </div>
                                        <!--<a href="#" class="hm-btn btn-primary uppercase">AGREGAR AL CARRITO</a>-->
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>

            </div>
        </div>



        <!-- =================================
           MEJORES ARTESANOS
        ================================== -->
        <div class="hm-page-block bg-fondo"></div>

        <div class="container">

            <div class="header-title" data-aos="fade-up">
                <h1>Mejores Artesanos</h1>
            </div>

            <iframe src="MejoresArtesanos/MejorArt.php" style="width: 100%; height: 600px; border: none;"></iframe>



        </div>

    </div>




    <!-- Animaciones : AOS-->
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

    <!-- Mi Script -->
    <script src="js/app.js"></script>

    <script>

        AOS.init({
            duration: 1200,
        })


    </script>

    <script>
        window.onload = function () {
            var height = document.body.scrollHeight;
            // Enviar el tamaño de la página al contenedor padre
            window.parent.postMessage(height, '*');
        };
    </script>


</body>

</html>