<?php
session_start();

// Obtener el rol de la sesión, si existe
if (isset($_SESSION['rol'])) {
    $rol = $_SESSION['rol']; // Se obtiene el rol de la sesión
} else {
    $rol = 'cliente'; // Si no hay rol, se asigna uno por defecto
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat-Munay</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        /* Estilos para el contenedor del chatbot */
        .chatbot-container {
            width: 400px;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            position: fixed;
            bottom: 100px;
            right: 20px;
            display: none; /* Oculto inicialmente */
            z-index: 1000;
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
        }
        .icono-chatbot {
            width: 100px;
            height: 100px;
        }
        .chat-box {
            height: 300px;
            overflow-y: auto;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
        }
        .user-message {
            text-align: right;
            color: #333;
            margin: 5px;
        }
        .chatbot-response {
            text-align: left;
            color: #D64045;
            margin: 5px;
        }
        /* Estilos para el campo de entrada y botón */
        #user-input {
            width: calc(100% - 80px);
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ddd;
            outline: none;
        }
        .chatbot-button {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #D64045;
            color: white;
            cursor: pointer;
            outline: none;
        }
        /* Botón de apertura/cierre del chatbot */
        #chatbot-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            background-color: #D64045;
            color: white;
            cursor: pointer;
            z-index: 1001;
        }
    </style>
</head>
<body>

    <!-- Botón para abrir/cerrar el chatbot -->
    <button onclick="toggleChatbot()" id="chatbot-toggle">Chat</button>

    <!-- Contenedor del chatbot -->
    <div class="chatbot-container" id="chatbot">
        <div class="header">
            <img src="imagenes/chat.webp" alt="Icono del chatbot" class="icono-chatbot">
            <h2>Chat-Munay</h2>
        </div>
        <div class="chat-box" id="chat-box">
            <!-- Aquí se mostrarán las respuestas del chatbot -->
        </div>
        <input type="text" id="user-input" placeholder="Escribe tu pregunta..." />
        <button onclick="enviarMensaje()" class="chatbot-button">Enviar</button>
    </div>

    <script>
        // Alterna la visibilidad del chatbot
        function toggleChatbot() {
            var chatbot = document.getElementById("chatbot");
            if (chatbot.style.display === "none" || chatbot.style.display === "") {
                chatbot.style.display = "block";
            } else {
                chatbot.style.display = "none";
            }
        }

        function enviarMensaje() {
            var message = document.getElementById("user-input").value;
            if (message.trim() === "") {
                alert("Por favor, ingresa un mensaje.");
                return;
            }
            // Enviar el mensaje al controlador de chatbot
            fetch('../controllers/chatbot_controller.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'message=' + encodeURIComponent(message) + '&rol=' + encodeURIComponent("<?php echo $rol; ?>")
            })
            .then(response => response.json())
            .then(data => {
                var chatBox = document.getElementById("chat-box");
                chatBox.innerHTML += "<div class='user-message'>" + message + "</div>";
                chatBox.innerHTML += "<div class='chatbot-response'>" + data.response + "</div>";
                document.getElementById("user-input").value = "";
                chatBox.scrollTop = chatBox.scrollHeight;
            })
            .catch(error => console.log("Error: ", error));
        }
    </script>

</body>
</html>
