<?php
session_start();
session_destroy(); // Destruir la sesión
header("Location: loginIniReg.php"); // Redirigir al login u otra página
exit();
?>
