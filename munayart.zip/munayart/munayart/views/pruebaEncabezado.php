<?php
// Iniciar la sesión antes de cualquier salida de HTML
session_start();
//print_r($_SESSION)
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>MunayArt</title>

    <!-- =================================
           PRINCIPAL
        ================================== -->

    <!-- FUENTE GOOGLE FONTS : Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700;800&display=swap"
        rel="stylesheet">

    <!-- ICONS: Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css">

    <!-- ICONS: Line Awesome -->
    <link rel="stylesheet"
        href="https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css">

    <!-- Animaciones AOS -->
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css">


    <!-- Mis Estilos -->
    <link rel="stylesheet" href="css/styles.css">

    <!-- =================================
           BOTON MENU
        ================================== -->
    <!-- Estilos para el menú lateral -->
    <style>
        /* Encabezado */
        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            height: 64px;
            background-color: #fff;
            position: relative;
            /* Para posicionar los menús absolutos */
        }

        /* Contenedor del logo */
        .logo-container {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-container img {
            max-height: 100px;
            max-width: 200px;
            height: auto;
        }

        .logo-container h3 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .logo-container a {
            text-decoration: none;
            color: #f17575;
            font-size: 14px;
            margin-left: 10px;
        }

        .logo-container a:hover {
            text-decoration: underline;
        }

        /* Menú principal (visible en pantallas grandes) */
        #menuHorizontal {
            display: flex;
            /* Mostrar en pantallas grandes */
            align-items: right;
            background-color: #fff;
            border-radius: 5px;
            padding: 0;
            white-space: nowrap;
            position: absolute;
            top: 5px;
            right: -100px;
            /* Ajusta según tu diseño */
        }

        /* Enlaces dentro del menú principal */
        #menuHorizontal a {
            padding: 5px 8px;
            height: 40px;
            text-decoration: none;
            color: rgb(17, 14, 14);
            font-size: 16px;
            display: flex;
            align-items: center;
            transition: 0.3s;
        }

        #menuHorizontal a:hover {
            background-color: #f17575;
            border-radius: 5px;
            color: #fff;
        }

        /* Botón de menú (visible en pantallas pequeñas) */
        .btn {
            display: none;
            /* Oculto por defecto, visible en pantallas pequeñas */
            width: 125px;
            height: 40px;
            border-radius: 5px;
            border: none;
            transition: all 0.5s ease-in-out;
            font-size: 20px;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
            font-weight: 600;
            display: flex;
            align-items: center;
            background: #040f16;
            color: #f5f5f5;
            cursor: pointer;
            position: relative;
            right: -150px;
        }

        .btn:hover {
            box-shadow: 0 0 20px 0px #2e2e2e3a;
        }

        .btn .icon {
            position: absolute;
            height: 40px;
            width: 70px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.5s;
        }

        .btn .text {
            transform: translateX(55px);
        }

        .btn:hover .icon {
            width: 175px;
        }

        .btn:hover .text {
            transition: all 0.5s;
            opacity: 0;
        }

        /* Menú alternativo (oculto por defecto) */
        #menuAlternativo {
            display: none;
            /* Oculto por defecto */
            flex-direction: column;
            align-items: flex-start;
            padding: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            position: absolute;
            top: 60px;
            /* Debajo del encabezado */
            right: 20px;
            z-index: 10;
        }

        /* Enlaces dentro del menú alternativo */
        #menuAlternativo a {
            font-size: 14px;
            padding: 10px;
            width: 100%;
            text-align: left;
            color: #333;
            text-decoration: none;
            transition: 0.3s;
        }

        #menuAlternativo a:hover {
            background-color: #f17575;
            color: #fff;
        }

        /* Media query para pantallas medianas y pequeñas */
        @media (max-width: 768px) {

            /* Ocultar menú principal */
            #menuHorizontal {
                display: none;
            }

            /* Mostrar botón de menú */
            .btn {
                display: flex;
                width: 120px;
                font-size: 16px;
            }

            /* Ajustes al encabezado */
            .header-container {
                flex-direction: column;
                padding: 10px;
                height: auto;
                /* Ajustar altura */
            }

            .logo-container {
                justify-content: center;
                margin-bottom: 10px;
            }
        }

        /* Media query para pantallas muy pequeñas */
        @media (max-width: 480px) {

            /* Ajustar botón de menú */
            .btn {
                width: 80px;
                font-size: 12px;
            }

            /* Ajustar enlaces del menú alternativo */
            #menuAlternativo a {
                font-size: 12px;
                padding: 8px;
            }
        }
    </style>




    <script>
        // Función para alternar el menú alternativo en pantallas pequeñas
        function toggleMenuAlternativo() {
            var menu = document.getElementById("menuAlternativo");
            if (menu.style.display === "flex") {
                menu.style.display = "none";
            } else {
                menu.style.display = "flex";
            }
        }

        // Asegurarse de que el menú alternativo esté oculto al cargar la página
        window.onload = function () {
            document.getElementById("menuAlternativo").style.display = "none";
        };
    </script>




</head>

<body>


    <!-- =================================
           HEADER MENU
        ================================== -->


    <div class="header-container">
        <!-- Contenedor del logo -->
        <div class="logo-container">
            <a href="#">
                <img src="imagenes/LogoNombre.png" alt="Logo">
            </a>
            <?php
            // Comprobar si el usuario ha iniciado sesión
            if (isset($_SESSION['user_name'])) {
                $user_name = $_SESSION['user_name'];
                echo "<h3>¡Bienvenido! $user_name</h3>";
                echo "<a href='logout.php' target='_top'>Cerrar sesión</a>";  // Enlace para cerrar sesión
            } else {
                // Si no hay una sesión de usuario, redirigir al login
                echo "<h3>¡Bienvenido!</h3>";
            }
            ?>

        </div>




        <!-- Menú principal (versión con efectos) -->
        <nav class="hm-menu">
            <div id="main">
                <!-- Este botón se muestra en pantallas grandes -->
                <button class="btn" onclick="toggleMenu()" id="menuPrincipalBtn">
                    <span class="icon">
                        <svg viewBox="0 0 175 80" width="40" height="40">
                            <rect width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                            <rect y="30" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                            <rect y="60" width="80" height="15" fill="#f0f0f0" rx="10"></rect>
                        </svg>
                    </span>
                    <span class="text">MENU</span>
                </button>

                <div id="menuHorizontal">
                    <a href="#" onclick="cambiarContenido('views/inicio.php')">Inicio</a>
                    <a href="#" onclick="cambiarContenido('views/filtradoProc/filtradoProduct.php')">Productos</a>
                    <a href="subir_producto.php" target="_top">Artesano</a>
                    <a href="productos/vista_pedido_delivery.php" target="_top">Delivery</a>
                    <a href="productos/vista_pedido_clientes.php" target="_top">Pedido</a>
                    <a href="#" onclick="cambiarContenido('views/nosotros.php')">Nosotros</a>
                </div>
            </div>
        </nav>

        <!-- Menú alternativo para pantallas pequeñas -->
        <nav class="simple-menu">
            <div id="menuAlternativo">
                <a href="#" onclick="cambiarContenido('views/inicio.php')">Inicio</a>
                <a href="#" onclick="cambiarContenido('views/filtradoProc/filtradoProduct.php')">Productos</a>
                <a href="subir_producto.php" target="_top">Artesano</a>
                <a href="productos/vista_pedido_delivery.php" target="_top">Delivery</a>
                <a href="productos/vista_pedido_clientes.php" target="_top">Pedido</a>
                <a href="#" onclick="cambiarContenido('views/nosotros.php')">Nosotros</a>
            </div>
        </nav>


        <!-- =================================
           HEADER MENU Movil
        ================================== -->




        <!-- Animaciones : AOS-->
        <script src="https://unpkg.com/aos@next/dist/aos.js"></script>

        <!-- Mi Script -->
        <script src="js/app.js"></script>

        <script>

            AOS.init({
                duration: 1200,
            })


        </script>

        <!-- =================================
           BOTON MENU
        ================================== -->
        <!-- Scripts para funcionalidad del menú -->
        <script>
            // Aseguramos que el menú esté oculto cuando se carga la página
            window.onload = function () {
                document.getElementById("menuHorizontal").style.display = "none";
            };

            // Función para mostrar y ocultar el menú horizontal
            function toggleMenu() {
                var menu = document.getElementById("menuHorizontal");
                if (menu.style.display === "none" || menu.style.display === "") {
                    menu.style.display = "flex"; // Muestra el menú
                } else {
                    menu.style.display = "none";  // Oculta el menú
                }
            }
        </script>

        <script>
            // Envía un mensaje al documento padre (la página principal) para cambiar el contenido
            function cambiarContenido(pagina) {
                window.parent.postMessage({ pagina: pagina }, '*');
            }
        </script>

</body>

</html>