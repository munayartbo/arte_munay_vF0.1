<?php
include '../../controllers/db_connection.php'; // Conexión a la base de datos

// Consulta para obtener los datos del artesano y su comunidad
$sql = "SELECT u.User, a.Imagen AS imagen_artesano, a.Descripcion, a.AniosExp, c.Imagen AS imagen_comunidad, c.Nombre AS nombre_comunidad
        FROM Artesano a
        JOIN Comunidad c ON a.CodComunidad = c.CodComunidad
        JOIN Usuario u ON a.CodArtesano = u.CodUsuario";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Artesanos y Comunidades</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="cssMejorArt.css">
</head>

<body>
    <div class="container">
        <div class="slide">
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) { ?>
                    <div class="item" style="background-image: url('../<?php echo $row['imagen_comunidad']; ?>');">
                        <h2 class="namec"><?php echo $row['nombre_comunidad']; ?></h2>
                        <div class="content">
                            <div>
                                <img src="../<?php echo $row['imagen_artesano']; ?>" alt="Imagen Artesano" style="width: 300px; height: 200px;">
                            </div>
                            <div class="name"><?php echo $row['User']; ?></div>
                            <div class="des">
                                Descripción: <?php echo $row['Descripcion']; ?><br>
                                Años de experiencia: <?php echo $row['AniosExp']; ?>
                            </div>
                        </div>
                    </div>
                <?php }
            } else {
                echo "<p>No hay artesanos disponibles.</p>";
            } ?>
        </div>

        <div class="button">
            <button class="prev"><i class="fa-solid fa-arrow-left"></i></button>
            <button class="next"><i class="fa-solid fa-arrow-right"></i></button>
        </div>
    </div>

    <script src="jsMejorArt.js"></script>
</body>

</html>
