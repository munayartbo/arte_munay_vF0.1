<?php
include('../../controllers/db_connection.php');
session_start();
$CodUsuario = $_SESSION['user_id'];

// Verificar si el formulario ha sido enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //var_dump($_POST);

    // Obtener el costo de envío basado en el CodEnvio seleccionado
    $codEnvio = $_POST['departamento'];

    // Obtener datos del envío
    $stmtEnvio = $conn->prepare("SELECT CodEnvio, departamento, costo_estimado FROM Envio WHERE CodEnvio = ?");
    $stmtEnvio->bind_param("i", $codEnvio);
    $stmtEnvio->execute();
    $resultEnvio = $stmtEnvio->get_result();

    if ($resultEnvio->num_rows > 0) {
        $envioData = $resultEnvio->fetch_assoc();
        $costoEnvio = $envioData['costo_estimado'];
        $departamento = $envioData['departamento'];
    } else {
        echo "Error: No se encontró información de envío para el departamento seleccionado.";
        exit();
    }
    $stmtEnvio->close();

    // Recoger datos del formulario
    $provincia = $_POST['provincia'];
    $calle = $_POST['calle'];
    $zona = $_POST['zona'];
    $nropuerta = $_POST['nropuerta'];
    $totalPago = $_POST['totalPago'];
    $codCarrito = $_POST['codCarrito'];

    // Detalles del pago

    $tipo = $_POST['pago'];
    $detalle = $_POST['detalle'];
    $nroTarjeta = $_POST['numero-tarjeta'];
    $cvv = $_POST['cvv'];
    $fechaV = date('Y-m-d H:i:s');

    // Insertar en la tabla Pago
    $sql_pago = "INSERT INTO Pago (Tipo, Total, Detalle, NroTarjeta, CVV, FechaV, CodCarrito, CodEnvio) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtPago = $conn->prepare($sql_pago);
    $stmtPago->bind_param("sdssssii", $tipo, $totalPago, $detalle, $nroTarjeta, $cvv, $fechaV, $codCarrito, $codEnvio);


    if ($stmtPago->execute()) {
        $CodPago = $conn->insert_id;

        // Generar el pedido
        $fecha = date('Y-m-d H:i:s');
        $estado = 'Pendiente';
        $sql_pedido = "INSERT INTO Pedido (Fecha, Estado, CodPago) VALUES (?, ?, ?)";
        $stmtPedido = $conn->prepare($sql_pedido);
        $stmtPedido->bind_param("ssi", $fecha, $estado, $CodPago);

        if ($stmtPedido->execute()) {
            $CodPedido = $conn->insert_id;

            // Insertar en la tabla Ubicacion
            $sql_ubicacion = "INSERT INTO Ubicacion (Departamento, Provincia, Calle, Zona, NroPuerta) VALUES (?, ?, ?, ?, ?)";
            $stmtUbicacion = $conn->prepare($sql_ubicacion);
            $stmtUbicacion->bind_param("ssssi", $departamento, $provincia, $calle, $zona, $nropuerta);

            if ($stmtUbicacion->execute()) {
                $CodUbicacion = $conn->insert_id;

                // Actualizar el pedido para incluir la ubicación
                $sql_actualizar_pedido = "UPDATE Pedido SET CodUbicacion = ? WHERE CodPedido = ?";
                $stmtActualizarPedido = $conn->prepare($sql_actualizar_pedido);
                $stmtActualizarPedido->bind_param("ii", $CodUbicacion, $CodPedido);

                if ($stmtActualizarPedido->execute()) {
                    // Aquí empieza la actualización del inventario
                    $sql_incluye = "SELECT CodProducto, Cantidad FROM Incluye WHERE CodCarrito = ?";
                    $stmtIncluye = $conn->prepare($sql_incluye);
                    $stmtIncluye->bind_param("i", $codCarrito);
                    $stmtIncluye->execute();
                    $resultIncluye = $stmtIncluye->get_result();

                    if ($resultIncluye->num_rows > 0) {
                        while ($rowIncluye = $resultIncluye->fetch_assoc()) {
                            $codProducto = $rowIncluye['CodProducto'];
                            $cantidadVendida = $rowIncluye['Cantidad'];

                            // Actualizar el inventario
                            $sql_actualizar_inventario = "UPDATE Inventario SET Cantidad = Cantidad - ?, FechaActualizacion = NOW() WHERE CodProducto = ?";
                            $stmtActualizarInventario = $conn->prepare($sql_actualizar_inventario);
                            $stmtActualizarInventario->bind_param("ii", $cantidadVendida, $codProducto);

                            if ($stmtActualizarInventario->execute()) {
                                echo "Inventario actualizado para el producto CodProducto: $codProducto.<br>";
                            } else {
                                echo "Error al actualizar el inventario para el producto CodProducto: $codProducto. " . $conn->error . "<br>";
                            }
                            $stmtActualizarInventario->close();
                        }
                    } else {
                        echo "No se encontraron productos en el carrito para actualizar el inventario.<br>";
                    }
                    $stmtIncluye->close();

                    echo "Pedido actualizado con la ubicación.<br>";
                } else {
                    echo "Error al actualizar el pedido con la ubicación: " . $conn->error;
                }
            } else {
                echo "Error al guardar la ubicación: " . $conn->error;
            }
        } else {
            echo "Error al crear el pedido: " . $conn->error;
        }
        header("Location: vista_pedido_clientes.php");
        exit();
    } else {
        echo "Error al crear el pago: " . $conn->error;
    }

    // Cerrar las declaraciones
    $stmtPago->close();
    $stmtPedido->close();
    $stmtUbicacion->close();

    // Cerrar la conexión
    $conn->close();
}
?>