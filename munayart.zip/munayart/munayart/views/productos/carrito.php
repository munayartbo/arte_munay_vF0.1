<?php
session_start();
include '../../models/db_connection.php'; // Incluye la conexión a la base de datos

// Verificar si el usuario está logueado
/*if (!isset($_SESSION['user_id'])) {
    echo json_encode(["status" => "error", "message" => "Usuario no autenticado"]);
    exit();
}*/
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CarpiShop</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css">
    <link rel="stylesheet" href="./css/main.css">
</head>

<body>

    <div class="wrapper">
        <header class="header-mobile">
            <button class="open-menu" id="open-menu">
                <i class="bi bi-list"></i>
            </button>
        </header>
        <aside>
            <button class="close-menu" id="close-menu">
                <i class="bi bi-x"></i>
            </button>
            <header>
                <a href="index.php" class="logo"><img src="img/LogoNombre.png" width="250px"></a>
                <?php
                // Comprobar si el usuario ha iniciado sesión
                if (isset($_SESSION['user_name'])) {
                    $user_name = $_SESSION['user_name'];
                    echo "<h3>¡Bienvenido! $user_name</h3>";
                    echo "<a href='../logout.php' target='_top'>Cerrar sesión</a>";  // Enlace para cerrar sesión
                    $CodCliente = $_SESSION['user_id'];

                } else {
                    // Si no hay una sesión de usuario, redirigir al login
                    echo "<h3>¡Bienvenido!</h3>";
                }
                ?>
            </header>
            <nav>
                <ul>
                    <li>
                        <a class="boton-menu boton-volver" href="./index.php">
                            <i class="bi bi-arrow-return-left"></i> Seguir comprando
                        </a>
                    </li>
                    <li>
                        <a class="boton-menu boton-carrito active" href="./carrito.php">
                            <i class="bi bi-cart-fill"></i> Carrito
                        </a>
                    </li>
                </ul>
            </nav>
            <footer>
                <p class="texto-footer">© 2024 MunayArt</p>
            </footer>
        </aside>
        <main>
            <h2 class="titulo-principal">Carrito</h2>
            <div class="contenedor-carrito">
                <p id="carrito-vacio" class="carrito-vacio">Tu carrito está vacío. <i class="bi bi-emoji-frown"></i></p>

                <div id="carrito-productos" class="carrito-productos disabled">
                    <!-- Esto se va a completar con el JS -->
                </div>

                <div id="carrito-acciones" class="carrito-acciones disabled">
                    <div class="carrito-acciones-izquierda">
                        <button id="carrito-acciones-vaciar" class="carrito-acciones-vaciar">Vaciar carrito</button>
                    </div>
                    <div class="carrito-acciones-derecha">
                        <div class="carrito-acciones-total">
                            <p>Total:</p>
                            <p id="total"></p>
                        </div>
                        <button id="carrito-acciones-comprar" class="carrito-acciones-comprar">Comprar ahora</button>
                    </div>
                </div>

                <p id="carrito-comprado" class="carrito-comprado disabled">Muchas gracias por tu compra. <i
                        class="bi bi-emoji-laughing"></i></p>

            </div>
        </main>
    </div>

    <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/toastify-js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="./js/carrito.js"></script>
    <script>
        // Verificar si existe una sesión activa
        <?php if (isset($_SESSION['user_id'])): ?>
            const codCliente = <?php echo json_encode($CodCliente); ?>;
        <?php else: ?>
            const codCliente = null;  // Asigna null si no hay usuario autenticado
        <?php endif; ?>
    </script>
    <script src="./js/menu.js"></script>
</body>

</html>