<?php
// Conexión a la base de datos con mysqli
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "munayart";
$port = "3307";

$conn = new mysqli($servername, $username, $password, $dbname, $port);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Obtener los datos enviados desde JS
$data = json_decode(file_get_contents('php://input'), true);
error_log(print_r($data, true)); // Registrar los datos recibidos

// Validar que se recibieron productos y un codCliente
if (!isset($data['productos']) || !isset($data['codCliente'])) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

$productos = $data['productos'];
$codCliente = $data['codCliente'];

if (empty($productos) || empty($codCliente)) {
    echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
    exit;
}

try {
    // Comenzar una transacción
    $conn->begin_transaction();

    // Insertar el nuevo carrito en la tabla "Carrito"
    $stmt = $conn->prepare("INSERT INTO Carrito (Fecha, Estado, CodCliente) VALUES (NOW(), 'pendiente', ?)");
    $stmt->bind_param("i", $codCliente);
    $stmt->execute();

    // Obtener el código del carrito recién insertado
    $codCarrito = $conn->insert_id;

    if (!$codCarrito) {
        throw new Exception("Error al obtener el código del carrito.");
    }

    // Insertar los productos en la tabla "Incluye"
    $stmtIncluye = $conn->prepare("INSERT INTO Incluye (CodCarrito, CodProducto, Cantidad) VALUES (?, ?, ?)");

    foreach ($productos as $producto) {
        // Imprimir para debug la cantidad y el id del producto
        error_log("ID Producto: " . $producto['id']);
        error_log("Cantidad: " . $producto['cantidad']);
        
        // Validar que la cantidad sea un número y mayor a 0
        $cantidad = isset($producto['cantidad']) ? (int)$producto['cantidad'] : 1;
        if (!is_numeric($cantidad) || $cantidad <= 0) {
            throw new Exception("Cantidad inválida para el producto {$producto['id']}");
        }

        // Verificar que el producto tiene un ID válido
        if (!isset($producto['id']) || !is_numeric($producto['id'])) {
            throw new Exception("ID de producto inválido.");
        }

        $stmtIncluye->bind_param("iii", $codCarrito, $producto['id'], $cantidad);

        // Ejecutar la consulta
        if (!$stmtIncluye->execute()) {
            error_log("Error MySQL: " . $stmtIncluye->error);
            throw new Exception("Error al insertar producto {$producto['id']} en la tabla Incluye: " . $stmtIncluye->error);
        }
    }

    // Confirmar la transacción
    $conn->commit();

    // Cerrar las declaraciones preparadas
    $stmt->close();
    $stmtIncluye->close();

    echo json_encode(['success' => true, 'codCarrito' => $codCarrito]);

} catch (Exception $e) {
    // Si algo falla, hacer rollback
    $conn->rollback();
    error_log($e->getMessage());
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

// Cerrar la conexión
$conn->close();
?>
