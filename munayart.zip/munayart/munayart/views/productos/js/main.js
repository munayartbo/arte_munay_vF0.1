

let productos = [];

// Cargar todos los productos al inicio
fetch("./productos.php")
    .then(response => response.json())
    .then(data => {
        productos = data;
        console.log("Productos cargados:", productos); // Verifica que los productos se estén cargando correctamente
        cargarProductos(productos); // Cargar todos los productos al inicio

        // Crear y disparar un evento personalizado para indicar que los productos están cargados
        const event = new Event('productosCargados');
        window.dispatchEvent(event);
    })
    .catch(error => console.error("Error al cargar los productos:", error));



const contenedorProductos = document.querySelector("#contenedor-productos");
const botonesCategorias = document.querySelectorAll(".boton-categoria");
const tituloPrincipal = document.querySelector("#titulo-principal");
let botonesAgregar = document.querySelectorAll(".producto-agregar");
const numerito = document.querySelector("#numerito");

// Cargar productos con sincronización de stock del localStorage
function cargarProductos(productosElegidos) {
    contenedorProductos.innerHTML = "";

    productosElegidos.forEach(producto => {
        // Verificar si el stock de este producto está en localStorage y usarlo si está disponible
        const stockGuardado = JSON.parse(localStorage.getItem("stocks-actualizados")) || {};
        const stockActual = stockGuardado[producto.id] !== undefined ? stockGuardado[producto.id] : producto.stock;

        const div = document.createElement("div");
        div.classList.add("producto");
        div.setAttribute("id", `producto-${producto.id}`);
        div.innerHTML = `
            <img class="producto-imagen" src="${producto.imagen}" alt="${producto.titulo}">
            <div class="producto-detalles">
                <h3 class="producto-titulo">${producto.titulo}</h3>
                <p class="producto-precio">Bs. ${producto.precio}</p>
                <p class="producto-stock">Stock: ${stockActual}</p>
                <label for="cantidad-${producto.id}">Cantidad:</label>
                <input type="number" id="cantidad-${producto.id}" min="1" value="1" 
                    class="producto-cantidad" max="${stockActual}" ${stockActual === 0 ? 'disabled' : ''}>
                <a style="text-decoration: none;" target="_top" href="../Producto_individual/detalles_producto.php?CodProducto=${producto.id}">
                    <button class="producto-detalles-boton">Ver Detalles</button>
                </a>
                <button class="producto-agregar" id="${producto.id}" ${stockActual === 0 ? 'disabled' : ''}>
                    ${stockActual > 0 ? 'Agregar' : 'Agotado'}
                </button>
            </div>
        `;
        contenedorProductos.append(div);
    });
    actualizarBotonesAgregar();
}





// Escuchar clics en botones de categoría
botonesCategorias.forEach(boton => {
    boton.addEventListener("click", (e) => {
        // Remover la clase 'active' de todos los botones y añadirla al botón actual
        botonesCategorias.forEach(boton => boton.classList.remove("active"));
        e.currentTarget.classList.add("active");

        if (e.currentTarget.id === "todos") {
            // Si se selecciona "Todos los productos", cargar todos los productos
            cargarProductos(productos);
            tituloPrincipal.innerText = "Todos los productos"; // Restablecer título
        } else {
            // Filtrar productos basados en el id del botón, que coincide con el tipo de producto
            const productosFiltrados = productos.filter(producto => producto.tipo.toLowerCase() === e.currentTarget.id.toLowerCase());

            // Actualizar el título principal y cargar los productos filtrados
            tituloPrincipal.innerText = e.currentTarget.innerText; // Usar el texto del botón como título
            cargarProductos(productosFiltrados);
        }
    });
});

// Función para actualizar botones de agregar al carrito
function actualizarBotonesAgregar() {
    botonesAgregar = document.querySelectorAll(".producto-agregar");

    botonesAgregar.forEach(boton => {
        boton.addEventListener("click", agregarAlCarrito);
    });
}

let productosEnCarrito;

let productosEnCarritoLS = localStorage.getItem("productos-en-carrito");

if (productosEnCarritoLS) {
    productosEnCarrito = JSON.parse(productosEnCarritoLS);
    actualizarNumerito();
} else {
    productosEnCarrito = [];
}

function agregarAlCarrito(e) {
    const idBoton = e.currentTarget.id;
    const producto = productos.find(p => p.id === idBoton);
    const inputCantidad = document.querySelector(`#cantidad-${idBoton}`);
    const cantidadSeleccionada = parseInt(inputCantidad.value);

    // Verificar si el producto ya está en el carrito y obtener su cantidad
    const productoEnCarrito = productosEnCarrito.find(p => p.id === idBoton);
    const cantidadEnCarrito = productoEnCarrito ? productoEnCarrito.cantidad : 0;

    // Validar stock disponible tomando en cuenta el stock actual menos lo que ya está en el carrito
    const stockDisponible = producto.stock - cantidadEnCarrito;
    if (cantidadSeleccionada > stockDisponible) {
        alert("La cantidad seleccionada supera el stock disponible.");
        return;
    }

    // Crear o actualizar producto en el carrito
    if (productoEnCarrito) {
        productoEnCarrito.cantidad += cantidadSeleccionada;
    } else {
        productosEnCarrito.push({ ...producto, cantidad: cantidadSeleccionada });
    }

    actualizarNumerito();
    localStorage.setItem("productos-en-carrito", JSON.stringify(productosEnCarrito));

    actualizarStockVisual(idBoton, cantidadSeleccionada);
}





function actualizarNumerito() {
    let nuevoNumerito = productosEnCarrito.reduce((acc, producto) => acc + producto.cantidad, 0);
    numerito.innerText = nuevoNumerito;
}


// Actualizar el stock en localStorage y en el DOM
function actualizarStockVisual(idProducto, cantidad) {
    const producto = productos.find(p => p.id === idProducto);
    if (producto) {
        const productoEnCarrito = productosEnCarrito.find(p => p.id === idProducto);
        const stockRestante = producto.stock - (productoEnCarrito ? productoEnCarrito.cantidad : 0);

        // Actualizar stock en localStorage
        const stocksActualizados = JSON.parse(localStorage.getItem("stocks-actualizados")) || {};
        stocksActualizados[idProducto] = stockRestante;
        localStorage.setItem("stocks-actualizados", JSON.stringify(stocksActualizados));

        // Actualizar el stock en el DOM
        const productoElemento = document.querySelector(`#producto-${idProducto}`);
        const stockElemento = productoElemento.querySelector(".producto-stock");
        const inputCantidad = productoElemento.querySelector(`#cantidad-${idProducto}`);
        const botonAgregar = productoElemento.querySelector(`.producto-agregar`);

        if (stockElemento) stockElemento.innerText = `Stock: ${stockRestante}`;
        if (inputCantidad) inputCantidad.max = stockRestante;

        if (stockRestante === 0 && botonAgregar) {
            botonAgregar.innerText = "Agotado";
            botonAgregar.disabled = true;
        }
    }
}


